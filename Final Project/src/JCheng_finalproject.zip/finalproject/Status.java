//*******************************************************************************
//* 																			*
//* 				CIS611 Spring 2017  Jeffrey Cheng							*		
//* 																			*	
//* 						Final Project					 					*
//* 																 			*
//* 		Status class provides different types to tell client and server		*	
//*				what to do.														*
//*																				*	
//* 																 			*
//* 					Date Created: 04.30.2017 					 			*
//*						Saved in: CustomerLogClient.java		 	 			*
//* 																 			*
//*******************************************************************************
package finalproject;

public enum Status {

	LOGIN_OP, CREATE_OP, VIEW_OP, SERACH_OP, BOOKING_OP, CLOSE_OP, VIEWFLIGHT_OP, CANCEL_OP, UPDATE_OP, CHECK_OP, DBALOGIN_OP, ADDFLIGHT_OP
}
